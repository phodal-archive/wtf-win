<!-- Keep a Changelog guide -> https://keepachangelog.com -->

# par-library-idea Changelog

## [Unreleased]
### Added
- Initial scaffold created from [IntelliJ Platform Plugin Template](https://github.com/JetBrains/intellij-platform-plugin-template)
