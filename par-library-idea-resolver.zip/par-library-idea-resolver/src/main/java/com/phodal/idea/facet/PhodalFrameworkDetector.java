package com.phodal.idea.facet;

import com.intellij.facet.FacetType;
import com.intellij.framework.detection.DetectedFrameworkDescription;
import com.intellij.framework.detection.FacetBasedFrameworkDetector;
import com.intellij.framework.detection.FileContentPattern;
import com.intellij.framework.detection.FrameworkDetectionContext;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.fileTypes.FileType;
import com.intellij.openapi.fileTypes.FileTypeManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ModifiableRootModel;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.patterns.ElementPattern;
import com.intellij.util.indexing.FileContent;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import java.util.List;

public class PhodalFrameworkDetector extends FacetBasedFrameworkDetector<PhodalFacet, PhodalFacetConfiguration> {
    private static final Logger LOG = Logger.getInstance(PhodalFrameworkDetector.class);

    public PhodalFrameworkDetector() {
        super("phodal");
    }

    @Override
    public @NotNull FileType getFileType() {
        return FileTypeManager.getInstance().getStdFileType("XML");
    }

    @Override
    public void setupFacet(@NotNull PhodalFacet facet, ModifiableRootModel model) {
        Module module = facet.getModule();
        Project project = module.getProject();

        LOG.info("project ---- " + project);

        VirtualFile[] contentRoots = model.getContentRoots();

        if (contentRoots.length == 1) {


        }

//        ImportDependenciesUtil.importDependencies(module, true);
    }

    @Override
    public @NotNull ElementPattern<FileContent> createSuitableFilePattern() {
        return FileContentPattern.fileContent().withName("phodal.xml");
    }

    @Override
    public @NotNull FacetType<PhodalFacet, PhodalFacetConfiguration> getFacetType() {
        return PhodalFacet.getFacetType();
    }

    @Override
    public List<? extends DetectedFrameworkDescription> detect(@NotNull Collection<VirtualFile> newFiles, @NotNull FrameworkDetectionContext context) {
        return super.detect(newFiles, context);
    }
}
