package com.phodal.idea.model;

import com.intellij.facet.FacetManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.Key;
import com.phodal.idea.facet.PhodalFacet;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface PhodalModel {
    Key<PhodalModel> KEY = Key.create(PhodalModel.class.getName());


    @Nullable
    static PhodalModel get(@NotNull PhodalFacet facet) {
        return facet.getUserData(KEY);
    }

    @Nullable
    static PhodalModel get(@NotNull Module module) {
        PhodalFacet facet = PhodalFacet.getInstance(module);
        return facet == null ? null : get(facet);
    }

    /**
     * Sets the model used by this PhodalFacet. This method is meant to be called from build-system specific code that sets up the project
     * during sync.
     *
     */
    static void set(@NotNull PhodalFacet facet, @Nullable PhodalModel PhodalModel) {
        facet.putUserData(KEY, PhodalModel);
        facet.getModule().getMessageBus().syncPublisher(FacetManager.FACETS_TOPIC).facetConfigurationChanged(facet);
    }
}
