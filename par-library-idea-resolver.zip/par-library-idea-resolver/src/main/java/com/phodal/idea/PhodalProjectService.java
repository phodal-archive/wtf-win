package com.phodal.idea;

import com.intellij.openapi.roots.libraries.Library;
import com.intellij.openapi.roots.libraries.LibraryTable;
import com.intellij.openapi.vfs.newvfs.BulkFileListener;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PhodalProjectService implements LibraryTable.Listener, BulkFileListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(PhodalProjectService.class);

    @Override
    public void afterLibraryAdded(@NotNull Library newLibrary) {
        LOGGER.info(newLibrary.getName());
    }

    @Override
    public void afterLibraryRenamed(@NotNull Library library) {
        LOGGER.info(library.getName());
    }

    @Override
    public void beforeLibraryRemoved(@NotNull Library library) {
        LOGGER.info(library.getName());
    }

    @Override
    public void afterLibraryRemoved(@NotNull Library library) {
        LOGGER.info(library.getName());
    }
}
