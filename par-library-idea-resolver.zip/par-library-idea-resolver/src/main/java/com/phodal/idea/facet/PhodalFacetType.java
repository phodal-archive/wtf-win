package com.phodal.idea.facet;

import com.intellij.facet.Facet;
import com.intellij.facet.FacetType;
import com.intellij.facet.FacetTypeId;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleType;
import icons.SdkIcons;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

public class PhodalFacetType extends FacetType<PhodalFacet, PhodalFacetConfiguration> {
    public static final String FACET_ID = "phodal";
    public static final String FACET_NAME = "Phodal Facet";

    public PhodalFacetType() {
        super(PhodalFacet.ID, FACET_ID, FACET_NAME);
    }

    @Override
    public PhodalFacetConfiguration createDefaultConfiguration() {
        return new PhodalFacetConfiguration();
    }

    @Override
    public PhodalFacet createFacet(@NotNull Module module,
                                 String s,
                                 @NotNull PhodalFacetConfiguration configuration,
                                 Facet facet) {
        return new PhodalFacet(this, module, s, configuration, facet);
    }

    @Override
    public boolean isSuitableModuleType(ModuleType moduleType) {
        return true;
    }

    @Override
    public @Nullable Icon getIcon() {
        return SdkIcons.Sdk_default_icon;
    }
}
