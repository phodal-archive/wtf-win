package com.phodal.idea.sync;

import com.intellij.execution.ExecutionException;
import com.intellij.execution.configurations.SimpleJavaParameters;
import com.intellij.openapi.externalSystem.model.DataNode;
import com.intellij.openapi.externalSystem.model.ExternalSystemException;
import com.intellij.openapi.externalSystem.model.project.ModuleData;
import com.intellij.openapi.externalSystem.model.project.ProjectData;
import com.intellij.openapi.externalSystem.model.task.TaskData;
import com.intellij.openapi.util.Pair;
import com.intellij.util.Consumer;
import com.phodal.idea.model.PhodalModuleModel;
import org.gradle.tooling.model.build.BuildEnvironment;
import org.gradle.tooling.model.idea.IdeaModule;
import org.gradle.tooling.model.idea.IdeaProject;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.plugins.gradle.service.project.GradleProjectResolverExtension;
import org.jetbrains.plugins.gradle.service.project.ProjectResolverContext;

import java.io.File;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import static com.phodal.idea.data.PhodalProjectKeys.PHODAL_MODULE_MODEL;
import static java.util.Collections.emptyList;

public class PhodalGradleProjectResolver implements GradleProjectResolverExtension {
    @NotNull protected GradleProjectResolverExtension nextResolver;
    @NotNull protected ProjectResolverContext resolverCtx;

    @Override
    public void setProjectResolverContext(@NotNull ProjectResolverContext projectResolverContext) {
        resolverCtx = projectResolverContext;
    }

    @Override
    public void setNext(@NotNull GradleProjectResolverExtension next) {
        assert next != null;
        nextResolver = next;
    }

    @Override
    public @Nullable GradleProjectResolverExtension getNext() {
        return nextResolver;
    }

    // todo: popular aar
    @Override
    public void populateProjectExtraModels(@NotNull IdeaProject gradleProject, @NotNull DataNode<ProjectData> ideProject) {

    }

    @Override
    public @Nullable DataNode<ModuleData> createModule(@NotNull IdeaModule gradleModule, @NotNull DataNode<ProjectData> projectDataNode) {
        return nextResolver.createModule(gradleModule, projectDataNode);
    }

    @Override
    public void populateModuleExtraModels(@NotNull IdeaModule gradleModule, @NotNull DataNode<ModuleData> ideModule) {

    }

    @Override
    public void populateModuleContentRoots(@NotNull IdeaModule gradleModule, @NotNull DataNode<ModuleData> ideModule) {
        File moduleRootDirPath = new File(ideModule.getData().getLinkedExternalProjectPath());
        String moduleName = ideModule.getData().getInternalName();

        PhodalModuleModel model = PhodalModuleModel.create(moduleName, moduleRootDirPath);
        ideModule.createChild(PHODAL_MODULE_MODEL, model);

        nextResolver.populateModuleContentRoots(gradleModule, ideModule);
    }

    @Override
    public void populateModuleCompileOutputSettings(@NotNull IdeaModule gradleModule, @NotNull DataNode<ModuleData> ideModule) {

    }

    @Override
    public void populateModuleDependencies(@NotNull IdeaModule gradleModule, @NotNull DataNode<ModuleData> ideModule, @NotNull DataNode<ProjectData> ideProject) {

    }

    @Override
    public @NotNull Collection<TaskData> populateModuleTasks(@NotNull IdeaModule gradleModule, @NotNull DataNode<ModuleData> ideModule, @NotNull DataNode<ProjectData> ideProject) {
        return nextResolver.populateModuleTasks(gradleModule, ideModule, ideProject);
    }

    @Override
    public @NotNull Set<Class<?>> getExtraProjectModelClasses() {
        return Collections.emptySet();
    }

    @Override
    public @NotNull Set<Class<?>> getToolingExtensionsClasses() {
        return Collections.emptySet();
    }

    @Override
    public @NotNull List<Pair<String, String>> getExtraJvmArgs() {
        return emptyList();
    }

    @Override
    public @NotNull List<String> getExtraCommandLineArgs() {
        return emptyList();
    }

    @Override
    public @NotNull ExternalSystemException getUserFriendlyError(@Nullable BuildEnvironment buildEnvironment, @NotNull Throwable error, @NotNull String projectPath, @Nullable String buildFilePath) {
        return nextResolver.getUserFriendlyError(buildEnvironment, error, projectPath, buildFilePath);
    }

    @Override
    public void preImportCheck() {

    }

    @Override
    public void enhanceTaskProcessing(@NotNull List<String> taskNames, @Nullable String jvmParametersSetup, @NotNull Consumer<String> initScriptConsumer) {

    }

    @Override
    public void enhanceRemoteProcessing(@NotNull SimpleJavaParameters parameters) throws ExecutionException {

    }
}
