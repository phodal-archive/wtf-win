package com.phodal.idea;

public class PhodalModuleSetup {

}
