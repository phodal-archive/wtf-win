package com.phodal.idea.model;

import com.google.common.annotations.VisibleForTesting;
import com.intellij.serialization.PropertyMapping;
import org.jetbrains.annotations.NotNull;

import java.io.File;

public class PhodalModuleModel implements PhodalModel {
    private static File moduleRootDirPath;
    @NotNull private final String myModuleName;

    @PropertyMapping({"myModuleName"})
    @VisibleForTesting
    PhodalModuleModel(@NotNull String moduleName) {
        myModuleName = moduleName;
    }

    public PhodalModuleModel(String moduleName, File moduleRootDirPath) {
        this.myModuleName = moduleName;
        this.moduleRootDirPath = moduleRootDirPath;
    }

    public static PhodalModuleModel create(String moduleName, File moduleRootDirPath) {
        return new PhodalModuleModel(moduleName, moduleRootDirPath);
    }

    @NotNull
    public String getModuleName() {
        return myModuleName;
    }
}
