package com.phodal.idea.data;

import com.intellij.openapi.externalSystem.model.Key;
import com.phodal.idea.model.PhodalModuleModel;
import org.jetbrains.annotations.NotNull;

import static com.intellij.openapi.externalSystem.model.ProjectKeys.LIBRARY_DEPENDENCY;

public final class PhodalProjectKeys {
  private static final int PROCESSING_AFTER_BUILTIN_SERVICES = LIBRARY_DEPENDENCY.getProcessingWeight() + 1;

  @NotNull
  public static final Key<PhodalModuleModel> PHODAL_MODULE_MODEL = Key.create(PhodalModuleModel.class, PROCESSING_AFTER_BUILTIN_SERVICES);

  private PhodalProjectKeys() {
  }
}
