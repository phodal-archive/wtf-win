package com.phodal.idea.facet;

import com.intellij.facet.*;
import com.intellij.openapi.module.Module;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PhodalFacet extends Facet<PhodalFacetConfiguration> {
    public static final FacetTypeId<PhodalFacet> ID = new FacetTypeId<>("phodal");

    public PhodalFacet(@NotNull FacetType facetType, @NotNull Module module, @NotNull String name, @NotNull PhodalFacetConfiguration configuration, Facet underlyingFacet) {
        super(facetType, module, name, configuration, underlyingFacet);
    }

    @Nullable
    public static PhodalFacet getInstance(@NotNull Module module) {
        return !module.isDisposed() ? FacetManager.getInstance(module).getFacetByType(ID) : null;
    }

    public static PhodalFacetType getFacetType() {
        return (PhodalFacetType) FacetTypeRegistry.getInstance().findFacetType(ID);
    }
}
