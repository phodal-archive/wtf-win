package com.phodal.idea;

import com.intellij.openapi.externalSystem.model.DataNode;
import com.intellij.openapi.externalSystem.model.Key;
import com.intellij.openapi.externalSystem.model.project.ModuleData;
import com.intellij.openapi.externalSystem.model.project.ProjectData;
import com.intellij.openapi.externalSystem.service.project.IdeModifiableModelsProvider;
import com.intellij.openapi.externalSystem.service.project.manage.AbstractProjectDataService;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.phodal.idea.data.PhodalProjectKeys;
import com.phodal.idea.model.PhodalModuleModel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class PhodalProjectDataService extends AbstractProjectDataService<PhodalModuleModel, Void> {
    @NotNull
    private final PhodalModuleSetup myModuleSetup;

    public PhodalProjectDataService() {
        this(new PhodalModuleSetup());
    }

    public PhodalProjectDataService(@NotNull PhodalModuleSetup myModuleSetup) {
        this.myModuleSetup = myModuleSetup;
    }

    @Override
    public @NotNull Key<PhodalModuleModel> getTargetDataKey() {
        return PhodalProjectKeys.PHODAL_MODULE_MODEL;
    }


    @NotNull
    private Map<String, PhodalModuleModel> indexByModuleName(@NotNull Collection<DataNode<PhodalModuleModel>> dataNodes,
                                                             @NotNull IdeModifiableModelsProvider modelsProvider) {
        if (dataNodes.isEmpty()) {
            return Collections.emptyMap();
        }
        Map<String, PhodalModuleModel> index = new HashMap<>();
        for (DataNode<PhodalModuleModel> dataNode : dataNodes) {
            PhodalModuleModel model = dataNode.getData();
            String moduleName = model.getModuleName();
            if (dataNode.getParent() != null) {
                ModuleData moduleData = (ModuleData) dataNode.getParent().getData();
                Module module = modelsProvider.findIdeModule(moduleData);
                if (module != null && !module.getName().equals(moduleName)) {
                    // If the module name in modelsProvider is different from in moduleData, use module name in modelsProvider as key.
                    // This happens when there are multiple *iml files for one module, which can be caused by opening a project created on a different machine,
                    // or opening projects with both Intellij and Studio, or moving existing module to different locations.
                    moduleName = module.getName();
                }
            }
            index.put(moduleName, model);
        }
        return index;
    }

    @Override
    public void importData(@NotNull Collection<DataNode<PhodalModuleModel>> toImport,
                           @Nullable ProjectData projectData,
                           @NotNull Project project,
                           @NotNull IdeModifiableModelsProvider modelsProvider) {
        Map<String, PhodalModuleModel> modelsByModuleName = indexByModuleName(toImport, modelsProvider);
        for (Module module : modelsProvider.getModules()) {
            PhodalModuleModel model = modelsByModuleName.get(module.getName());
            setupModule(module, modelsProvider, model);
        }
    }

    private void setupModule(Module module, IdeModifiableModelsProvider modelsProvider, PhodalModuleModel model) {
//        new AndroidFacetModuleSetupStep();
//        new SdkModuleSetupStep();
//        new JdkModuleSetupStep();
//        new ContentRootsModuleSetupStep();
//        new DependenciesAndroidModuleSetupStep();
//        new CompilerOutputModuleSetupStep();

        DependenciesAndroidModuleSetupStep setupStep = new DependenciesAndroidModuleSetupStep();
        setupStep.setupModule(module, model);
    }
}
