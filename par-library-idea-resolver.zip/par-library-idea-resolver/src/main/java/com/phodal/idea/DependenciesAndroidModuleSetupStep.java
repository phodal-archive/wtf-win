package com.phodal.idea;

import com.intellij.openapi.module.Module;
import com.phodal.idea.model.PhodalModuleModel;

public class DependenciesAndroidModuleSetupStep {
    public DependenciesAndroidModuleSetupStep() {

    }

    public void setupModule(Module module, PhodalModuleModel model) {
        System.out.println(module);
        System.out.println(model);
    }
}
