package com.phodal.idea.facet;

import org.jetbrains.annotations.NotNull;

public class PhodalFacetState {
    static final String PHODAL_FACET_INIT_PATH = "";

    public String myPathToSdk;

    PhodalFacetState() {
        setPhodalFacetState(PHODAL_FACET_INIT_PATH);
    }

    @NotNull
    public String getPhodalFacetState() {
        return myPathToSdk;
    }

    public void setPhodalFacetState(@NotNull String newPath) {
        myPathToSdk = newPath;
    }

}
