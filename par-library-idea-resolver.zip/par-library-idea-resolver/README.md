# par-library-idea

## Simple Library

 - https://github.com/redhat-developer/intellij-quarkus

## Open Import

```java
/**
 * Do not use this project import builder directly.
 *
 * Internal stable Api
 * Use [com.intellij.ide.actions.ImportModuleAction.doImport] to import (attach) a new project.
 * Use [com.intellij.ide.impl.ProjectUtil.openOrImport] to open (import) a new project.
 *
 * Internal experimental Api
 * Use [org.jetbrains.plugins.gradle.service.project.open.openGradleProject] to open (import) a new gradle project.
 * Use [org.jetbrains.plugins.gradle.service.project.open.linkAndRefreshGradleProject] to attach a gradle project to an opened idea project.
 */
```

## Documents

[External System Integration](https://jetbrains.org/intellij/sdk/docs/reference_guide/frameworks_and_external_apis/external_system_integration.html)


https://intellij-support.jetbrains.com/hc/en-us/community/posts/206101849-Programmatically-add-external-libraries-for-custom-LibraryKind

```kotlin
private fun createLibraryDependency(module: Module, project: Project,
                                    libraryName: String, dubPackage: DubPackage) {
    val sources = getSourcesVirtualFile(dubPackage)
    val projectLibraryTable = LibraryTablesRegistrar.getInstance()
        .getLibraryTable(project)
    val projectLibraryModel = projectLibraryTable
        .modifiableModel

    val library = projectLibraryModel.createLibrary(libraryName)
    val libraryModel = library.modifiableModel

    if (sources != null) {
        libraryModel.addRoot(sources, OrderRootType.CLASSES)
        //todo add binary libs/dub.json as well
        ApplicationManager.getApplication()
            .invokeAndWait {
                ApplicationManager.getApplication().runWriteAction {
                    libraryModel.commit()
                    projectLibraryModel.commit()
                    for (projectModule in ModuleManager.getInstance(project)
                        .modules) {
                        ModuleRootModificationUtil.addDependency(projectModule, library)
                    }

                }
            }

    }
}
```

plugins.xml

```xml
<!-- library -->
<library.type implementation="io.github.intellij.dlanguage.library.DlangLibraryType"/>
<orderRootType implementation="io.github.intellij.dlanguage.library.LibFileRootType" id="LIBRARY_FILE"
               order="FIRST"/>
<OrderRootTypeUI key="LIBRARY_FILE"
                 implementationClass="io.github.intellij.dlanguage.library.LibFileRootTypeUIFactory"/>
```


```
/**
 * Provides automatic detection of root type for files added to a library. Implementations of this class should be returned from
 * {@link LibraryRootsComponentDescriptor#getRootDetectors} method
 *
 * @see RootFilter
 * @see DescendentBasedRootFilter
 */
```


![Build](https://github.com/rapilab/par-library-idea/workflows/Build/badge.svg)
[![Version](https://img.shields.io/jetbrains/plugin/v/PLUGIN_ID.svg)](https://plugins.jetbrains.com/plugin/PLUGIN_ID)
[![Downloads](https://img.shields.io/jetbrains/plugin/d/PLUGIN_ID.svg)](https://plugins.jetbrains.com/plugin/PLUGIN_ID)

## Template ToDo list
- [x] Create a new [IntelliJ Platform Plugin Template][template] project.
- [ ] Verify the [pluginGroup](/gradle.properties), [plugin ID](/src/main/resources/META-INF/plugin.xml) and [sources package](/src/main/kotlin).
- [ ] Review the [Legal Agreements](https://plugins.jetbrains.com/docs/marketplace/legal-agreements.html).
- [ ] [Publish a plugin manually](https://www.jetbrains.org/intellij/sdk/docs/basics/getting_started/publishing_plugin.html) for the first time.
- [ ] Set the Plugin ID in the above README badges.
- [ ] Set the [Deployment Token](https://plugins.jetbrains.com/docs/marketplace/plugin-upload.html).
- [ ] Click the <kbd>Watch</kbd> button on the top of the [IntelliJ Platform Plugin Template][template] to be notified about releases containing new features and fixes.

<!-- Plugin description -->
This Fancy IntelliJ Platform Plugin is going to be your implementation of the brilliant ideas that you have.

This specific section is a source for the [plugin.xml](/src/main/resources/META-INF/plugin.xml) file which will be extracted by the [Gradle](/build.gradle.kts) during the build process.

To keep everything working, do not remove `<!-- ... -->` sections. 
<!-- Plugin description end -->

## Installation

- Using IDE built-in plugin system:
  
  <kbd>Preferences</kbd> > <kbd>Plugins</kbd> > <kbd>Marketplace</kbd> > <kbd>Search for "par-library-idea"</kbd> >
  <kbd>Install Plugin</kbd>
  
- Manually:

  Download the [latest release](https://github.com/rapilab/par-library-idea/releases/latest) and install it manually using
  <kbd>Preferences</kbd> > <kbd>Plugins</kbd> > <kbd>⚙️</kbd> > <kbd>Install plugin from disk...</kbd>


---
Plugin based on the [IntelliJ Platform Plugin Template][template].

[template]: https://github.com/JetBrains/intellij-platform-plugin-template
